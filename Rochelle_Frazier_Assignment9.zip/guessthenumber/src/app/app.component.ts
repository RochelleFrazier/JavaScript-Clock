import { Component } from '@angular/core';

@Component({
  // Template of Guess The Number Application
  selector: 'app-root',
  template: `
    <div class="container">
      <h2>Guess the Number !</h2>
      <div class="card bg-light mb-3">
        <div class="card-body">
          <p class="card-text">
            Guess the computer generated random number between 1 and 1000.
          </p>
        </div>
      </div>
      <div>
        <label>Your Guess: </label>
        <input
          type="number"
          [value]="guess"
          (input)="guess = $event.target.value"
        />
        <button (click)="verifyGuess()" class="btn btn-primary btn-sm">
          Verify
        </button>
        <button (click)="initializeGame()" class="btn btn-warning btn-sm">
          Restart
        </button>
      </div>
      <div>
        <p *ngIf="deviation < 0" class="alert alert-warning">
          Your guess is higher.
        </p>
        <p *ngIf="deviation > 0" class="alert alert-warning">
          Your guess is lower.
        </p>
        <p *ngIf="deviation === 0" class="alert alert-success">
          Yes! That's it.
        </p>
      </div>
      <p class="text-info">
        No of guesses :
        <span class="badge">{{ noOfTries }}</span>
      </p>
    </div>
  `,

  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  deviation: number; //Giving the user hints to improve their guess based on their input
  noOfTries: number; //Tracking the number of guesses already made
  original: number; //Generating random numbers
  guess: number; //Providing input for a user to guess the value
  title: Text; //Title

  // calls to initializeGame()
  constructor() {
    this.initializeGame();
  }
  initializeGame() {
    this.noOfTries = 0;
    this.original = Math.floor(Math.random() * 1000 + 1); //generates random number
    this.guess = null; //clears input value
    this.deviation = null;
  }

  //updates deviation and number of tries
  verifyGuess() {
    this.deviation = this.original - this.guess;
    this.noOfTries = this.noOfTries + 1;
  }
}
