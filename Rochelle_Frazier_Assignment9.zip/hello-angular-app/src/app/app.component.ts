import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'My First Angular Application'; //title
  subtitle = 'Say Hello to Angular. Push the button to say hello!'; //subtitle
  hello = ''; // once button is clicked, value hello will display this.hello text

  OnHelloClick(): String {
    this.hello = 'Hello Angular!'; //shows in textbox once button is clicked
    return 'Hello Angular';
  }
}
